# PyStore

PyStore is a digital store application, where you can buy certain items.
I made this project in order to learn how to work with JSON files in a "real-world-scenario".

# Features
* View how much money you have
* Buy items
* Reset store to defaults

# Usage

### To buy items:
* open `PyStore.bat`
* type the action you want to execute
* follow instructions on screen

### To reset all values:
* open `reset.bat`
* reset will happen automatically
